acSetRescSchemeForCreate {
  msiSetDefaultResc("demoResc","null");
  msiSetRescSortScheme("random");
  msiSetRescSortScheme("byRescClass");
}
