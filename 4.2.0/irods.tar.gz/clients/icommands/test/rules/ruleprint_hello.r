myTestRule {
#  Output string is written to stdout
  writeLine("stdout","Execute command to print out hello");
  print_hello;
}
INPUT null
OUTPUT ruleExecOut
