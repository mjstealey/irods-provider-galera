acSetPublicUserPolicy {msiSetPublicUserOpr("read%query");}
