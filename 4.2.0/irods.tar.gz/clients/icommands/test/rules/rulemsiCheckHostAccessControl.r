acChkHostAccessControl {
#No arguments
#  The file server/config/HOST_ACCESS_CONTROL_FILE
#  is read to identify hosts that can access iRODS.
  msiCheckHostAccessControl;
}
